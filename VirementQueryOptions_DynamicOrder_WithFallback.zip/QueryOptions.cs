
using System.Linq.Expressions;

namespace MyProject.Application.Common;

public class QueryOptions<T, TResult>
{
    public Expression<Func<T, bool>>? Filter { get; set; }
    public List<Expression<Func<T, object>>> Includes { get; set; } = new();
    public Expression<Func<T, TResult>>? Selector { get; set; }
    public int? Skip { get; set; }
    public int? Take { get; set; }

    public string? OrderByProperty { get; set; }
    public bool OrderByDescending { get; set; }
}
