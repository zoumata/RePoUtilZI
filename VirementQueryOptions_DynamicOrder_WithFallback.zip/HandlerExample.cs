
var options = new QueryOptions<Virement, VirementDto>
{
    Filter = v => string.IsNullOrEmpty(f.MotCle) || v.Beneficiaire.Contains(f.MotCle),
    Selector = v => new VirementDto
    {
        Id = v.Id,
        Beneficiaire = v.Beneficiaire,
        Montant = v.Montant,
        DateCreation = v.DateCreation
    },
    Skip = f.PageIndex * f.PageSize,
    Take = f.PageSize,
    OrderByProperty = f.TriColonne,
    OrderByDescending = f.TriSens?.ToLower() != "asc"
};
