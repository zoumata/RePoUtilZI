
using System.Linq.Expressions;
using System.Reflection;

public static class QueryableExtensions
{
    public static IOrderedQueryable<T> OrderByDynamic<T>(
        this IQueryable<T> source,
        string propertyName,
        bool descending = false)
    {
        try
        {
            var param = Expression.Parameter(typeof(T), "x");
            var property = Expression.PropertyOrField(param, propertyName);
            var lambda = Expression.Lambda(property, param);

            var methodName = descending ? "OrderByDescending" : "OrderBy";
            var method = typeof(Queryable).GetMethods()
                .First(m => m.Name == methodName && m.GetParameters().Length == 2)
                .MakeGenericMethod(typeof(T), property.Type);

            return (IOrderedQueryable<T>)method.Invoke(null, new object[] { source, lambda })!;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[OrderByDynamic] Invalid property: {propertyName} - {ex.Message}");
            return (IOrderedQueryable<T>)source; // fallback no sorting
        }
    }
}
