
if (!string.IsNullOrEmpty(options.OrderByProperty))
{
    query = query.OrderByDynamic(options.OrderByProperty, options.OrderByDescending);
}
